DotA Replay Manager 2.05

http://forums.dota-allstars.com/index.php?showtopic=271794
http://www.playdota.com/forums/showthread.php?p=110886
http://rivsoft.narod.ru/dotareplay.html

============== Changelog ==================================
**2.05**
 - Fixed chat log search to be case insensitive
 - Added search for Action Log
 - Added rightclick menu for Action Log that allows copying lines
 - Fixed "Copy name" option from rightclick menu in game info tab (it used to copy broken text)
 - Added assists to "Copy stats" option from rightclick menu in game info tab
 - Added "Copy matchup" button on game info tab, copies list of players and heroes in one line
 - Fixed some crashes
 - Fixed gold timeline (integer overflow ftl)
 - Finally added drag-and-drop support for folder view (tree view still doesn't support it)
 - Fixed draft view to work for -cm (note that dota is bugged atm and only lists sentinel picks/bans
  in -cd)
 - Added streaks and kill combos to game chat and timeline view (use Chat Filters button on top
  right to hide them)
 - Added support for -switch mode, colors in chat now correctly display the player's current color and
  it doesn't say "has been killed by his teammate" incorrectly anymore
 - Using blink dagger doesn't drop wards all over the timeline picture as much; the solution is still
  temporary and needs more replay data to work correctly
 - Added assists to game chat (disabled by an option in Settings), note that dota is bugged atm and doesn't
  store this information correctly
 - Removed the 8192 size limit on cache; gamecache now uses game date/time as a key instead of filename,
  this should remove duplicate replays, there is a very low chance that two different replays have the same
  date/time. As a side effect gamecache file may grow very large, delete it and cache replays again if it
  causes trouble
 - Fixed hero chart to show correct heroes and games
 - Added game mode filter to hero chart (suggested by tk1)
 - Added buildings to Timeline view, they should correctly disappear when they are destroyed. Timeline view
  is now resizable, map image has been updated to the latest version. Dead heroes now disappear correctly
 - Fixed odd time marks in graph views (e.g -0:58 to -1:00)
 - Added PlayDota smiley tags for items (assuming urn will be :urn: when it is added)
**2.04**
 - Happy New Year
 - Fixed some bugs
 - Fixed hero chart a little, it now shows the heroes in the correct order as they appear in taverns
 - Updated to 6.65 (the only difference between this and automaticaly loading data is that icons
  will update properly)
 - Added support for new replay data: roshan, aegis, runes, correct gamemode, hero levels (affects
  xp timeline)
 - Now recognizes game start (creep spawn) and adjusts lane detection accordingly, added option to
  show all times relative to creep spawn like in actual game
 - Fixed scepter recipe and items purchased in the side shops
 - Added Draft tab, showing hero pool for -cd and bans/picks for -cd/-cm (sorry, haven't tested this
  at all since I don't have any 6.65 -cd replays, so if it doesn't I'll hotfix it later)
 - Added Action log tab, which shows a very detailed low level log of the game (I'll add search function
  for it soon). It shows hero/item/ability/etc icons and names wherever applicable, player colors
  etc, and works with any map, not only dota (the map must be in your wc3 folder under the name
  specified in the replay). Loading map and re-parsing the replay takes about 10 seconds.
 - Haven't fixed crashes yet, I'll work for it soon
**2.03**
 - Fixed various crashes
 - Fixed Sven's icon in hero chart (reported by Jager)
 - Fixed other heroes' skills appearing in build view
**2.02b**
 - Added colored names/hero names in timeline tab as well
 - Fixed techies icon and a few others
**2.02**
 - From now on, instead of resources.mpq the program will come with patch.mpq and when you run
  it the first time it will merge the two files - don't rename anything yourself. This way map
  data you loaded yourself will not be erased after every patch
 - Fixed some more bugs in reading player stats
 - Added an option to show hero names in chat log
 - Colored player names in chat events (e.g. hero kills)
 - Added chat search function (by text or by player)
 - Added chat filters (e.g. only show hero kills)
 - Updated the list of forum icons for Presentation tab (like :puck:)
 - Added a set of forum icons for playdota.com
**2.01b**
 - Fixed to correctly read recipes again
**2.01**
 - Fixed major bug that prevented players and stats from loading correctly
 - Fixed to work with 6.60+
 - Fixed a bug that prevented upgradeable skills from registering correctly
  (e.g. all ultimates affected by scepter, Ogre Magi abilities etc.)
 - Changed hero chart a little to accomodate 9 taverns
**2.00**
 - Major rewrite, the program now reads all DotA data from the map
 - Hero kills, tower/rax kills etc. are now shown in game chat
 - Added "Use D-A forum icons" in Presentation tab, which forces the program to use dota-allstars
  forum icons for heroes (e.g. :cmai:)
**1.05**
 **NOTE** Since much of the program was adapted to unicode and thus gamecache format has
  changed. If you see a lot of games with bad game names in the folder view (it should only
  happen to local games) you should consider caching replays again (button in settings).
  Also since a LOT major changes have been introduced expect new bugs >.<
 - The window is now resizeable
 - Added sentinel and scourge total gold in gold timeline mode (suggested by HiT0Mi)
 - Reworked a lot of stuff to hopefully work properly with unicode. Game Chat and Timeline
  modes should display chinese and other languages properly, and player names using
  non-english letters should work better now.
 - Added progress bar when folder is being populated (since it takes a while in some cases).
 - Fixed game mode determination to match the one in DotA, and adjusted lane determination
  to work better with modes that make creeps spawn at 2:00 (MM, VR and AP)
 - Fixed replay decompression algorithm to work with non-standard replays made at replays.net,
  garena and the like
 - Optimized replay parsing algorithm for caching data
 - Added minimap image to Game Info mode (click to enlarge)
 - Added replay workshop (remove chat messages and pings from the replay)
 - Countless minor bugfixes
 - Finally added map parser. For now it only parses abilities - that is it should now correctly
  determine which skills the heroes have
**1.04b**
 - I hope it now REALLY works for 6.52(c)
 - Fixed version number in the program
**1.04**
 - Updated for 6.52 (haven't tested thoroughly yet)
 - Removed the error dialogs that popped up when invalid replay file was opened (to simplify
  listing through the replays)
 - Some bug fixes
**1.03b**
 - Added "Copy player name" item to drop down menu in game info tab
**1.03**
 - Fixed both impales and god's strength to work with new versions
 - Game length is now correct, it indicates when the tree/throne went down (if the game was
  finished)
**1.02b**
 - Fixed several bugs with hero chart
 - Added some support for ladder replays (game info, game chat and action tabs work)
 - Changed date format in rename template from DD-MM-YYYY to YYYY-MM-DD for correct replay order
  when sorted alphabetically (suggested by greater.morphling)
**1.02**
 - Adapted to 6.51
 - Made separate repeated action delays for skills and items
 - Fixed a bug with columns in search mode
 - Tree view gets automatically updated every time a new replay is detected
 - Added hero chart, which shows replays for different heroes (another item in the tree view)
**1.01b**
 - Added your own name box to settings to use when replay saver was not properly identified (if
  the game was not finished)
 - The screenshot parser counts copies of the same game once now
 - Added "Show player stats" button to game info tab to display information similar to screenshot
  parser mode
 - Fixed some composite items in item build (Orchid and Guinsoo)
 - Eliminated OpenGL usage in gold/exp timeline and actions (Timeline mode still uses it)
**1.01**
 - Fixed a bug in gold/exp timeline for games less than 5v5 (if, say, purple was missing then
  yellow will take his place and there will be some problems)
 - Fixed loading images for 16 bit color desktop (problem reported by RockBuster)
 - Added experimental screenshot parsing feature (join a game, press Print Screen, select Parse
  screenshot item in the tree view, you will see the list of players that joined the game. Works
  pretty well in 1280x1024 but has problems with other resolutions)
 - Added "By date" option for the tree view
 - When you batch copy/backup a replay cached information will be copied as well, this removes a
  large delay that can appear if you open the folder with back up'ed replays after playing a lot
  of games
**1.00**
 - Adapted to 6.50: added invoker, fixed new skills for Drow ranger and Necro'lic, changed
  recipes/item costs
 - Fixed time in Gold/Exp timelines
 - Fixed a bug in presentation mode which caused the program to crash when certain options
  were set (by K[a]ne)
 - Added "Reset" button in settings
 - It is recommended that you increase Repeated action delay in settings to something like 3
  or even 5 seconds. The new skill algorithm should fix most errors this change may cause,
  and I've seen replays where someone managed to click the skill 3 times with a 4 second
  interval
 - Added an option to remove basic commands (e.g. rightclick, move/attack/stop, pre
  subselection) from log files
 - Added an option to make Gold timeline smoother (because when player buys many items on
  the same fountain trip the timeline looks awkward)
 - Added game mode option in Present tab
**0.98b**
 - Fixed old N'aix, Replicate
 - Fixed one option in the settings which appeared in both tabs by mistake
 - Improved skill learning algorithm (repeated actions are now handled better)
 - Added experience timeline tab
**0.98**
 - Made brown and purple a little lighter for better presentation (suggested by RaMbOMaN)
 - Added player statistics - lists games for given player. Type "Player:<name>" in path bar
  or right click player in game info and select Find games (suggested by SnowWar)
 - Player build and actions tab now share selection (selecting a player in one will select
  the same player in another)
 - Added button for caching all replays in the Replays folder (you need to click it if you
  want to use player statistics
 - Added browse button for replay path
**0.97b**
 - Fixed bottom and mid lanes which were swapped by mistake in one of the last versions
**0.97**
 - Fixed a couple bugs that caused the program to crash when players did not select a hero
 - Fixed -sp mode which was not working correctly
 - Added keyboard shortcuts for file list view (Ctrl-C, Ctrl-V, Enter, F2, Delete)
 - Fixed dagon and necrobook, now base items are properly grayed
**0.96b**
 - Improved winner determination: if none of the methods worked the program checks player's
  positions and if too many are inside enemy base then they are considered winners
 - You can now copy player stats from Game info tab (Ctrl-C) (suggested by FoR)
**0.96**
 - Improved gold timeline visualisation (added lines)
 - Added replay search function (next to Explore button in folder view mode)
 - Enabled loading replays directly from internet (as long as the filename starts with http:)
**0.95**
 - Added longest AFK time in actions tab
 - Added gold timeline tab, displaying build costs over time for all players on a single graph
 - Added game mode identification (even if saver wasn't sentinel), added game commands to game chat
 - Enabled detail view in file list (option in settings)
 - Lane detection algorithm fixed to work better with -rd (from 2:00-5:00 to 3:30-6:30)
**0.94b**
 - Slippers of agility fixed, got wrong item id last time =(
 - Removed the log file which I forgot to remove last time (if you need it it's in the options now)
 - Fixed setting this program as default replay program, now it works if you didn't install WC3 on
   the computer (it adds all necessary keys and sets the icon), also if WC3 wasn't properly installed
   and replays weren't opened with it turning this option on and off will properly bind replays to WC3
 - It will now detect 6.49c properly since IceFrog never used 'c' suffix (AFAIK)
**0.94**
 - Added combined items in item build, recipe scrolls now have a scroll icon (option available in
   the settings menu)
 - Colored skills in skill build view (option available in the settings menu)
 - Synchronized selection in skill and item build lists (option available in the settings menu)
 - Added tabs for settings (they don't fit on one page anymore)
**0.93b**
 - Fixed a lot of skills on heroes with engineering upgrade-based skills: Ogre Magi, Krobelus,
   Syllabear and all aghanim users
 - Added skill levels to build view (option added to settings)
 - Added player colors in combo boxes (player selection), also added unselectable Sentinel and
   Scourge entries
 - Added support for Open With function, added option to set this program as default for opening
   replays
 - You can drag replay files from Explorer into this program now
**0.93**
 - Uncapped replay speed, now it can be from -99 to 99 (suggested by esby)
 - Added minimap pings to timeline mode
 - Tweaked presentations a bit
 - Added update checking
 - Added player colors in lists
**0.92b**
 - Fixed fissure in versions < 6.49
 - Fixed endgame info for < 6.49 and -sp mode in >= 6.49
**0.92**
 - Fixed "Watch replay" button. Now instead of "double clicking" the replay it properly finds WC3
   install path and passes the replay. Also added an option to launch WC3 in windowed mode.
 - Added a lot of options to Settings menu
 - Added wards for Timeline tab.
 - Rewrote file operations (delete and paste) to use system functions - to show progress bar and
   for familiar interface.
 - Added Presentation tab with tons of options.
 - Fixed some abilities (that either were not detected or belonged to a wrong hero).
===========================================================

I know there are a lot of other replay parsers around but I'm sure some of my features are unique.
Here are some of the features:
 - Explorer-like replay browser (tree view+list fiew) with functions for copy/paste, delete/rename
   and creating folders.
 - Auto-copying new replays (from LastReplay.w3g) and batch copying
 - Replay search with a lot of options like game name, length, map version, player names and heroes.
 - Can load replays from internet if filename starts with http:

Replay parsing features:
 - Displays game information like date, patch, map, game name, host, saver, length, players, score,
   winner and observers.
 - Displays player list with level, buildcost, stats, lane, APM (actions per minute) and leave time.
 - Colored chat view, probably works with other languages (tested with russian)
 - Timeline view - displays roughly *estimated* hero movement over time - an animated version of the
   replay with many features.
 - Hero builds - skills and items
 - Action charts - including different action types, group hotkeys used, and APM over time graph.
 - Gold timeline - compare build costs over time for all players
 - Presentation tab - format the replay in plain text mode, forum BB codes or HTML, for example to
   post a replay in DotA replays forum.

============== User interface =============================
 Make sure the folder with replay manager contains file "resources".
 Launch DotA Replay Manager. The left part of the window contains a tree view of your replay folder.
If Warcraft III was not detected (it should be if it was launched at least once on this computer) it
will show the folder from which the program was launched and you need to set the proper path in
Settings (first item in the list). The tree view also displays the number of replay files in a given
folder and its subfolders.
 By default, the tree view is built based on the replay folder structure. You can choose to build it
based on replay date by checking the "By date" box. Then the tree view will contain separate folders
for different years, months and days (note that replays with matching time are nearly always copies
of the same replay and thus are shown as a single file).
 The program has two main modes: file browsing and replay information.

 To enter file browsing mode, click on any folder in the tree view. The right part of the screen will
show a list of files in that folder (only folders and .w3g files are shown).
You can enter a subdirectory by double clicking it (to move to parent directory double click the
[Up One Level] item). Double clicking a replay file will switch the program to replay information mode.
If you right-click an item in the list a context menu with several options will appear.
 To search for a replay click on Search button. In the dialog select desired options and click Search.
 To batch copy files select one or more files (if you do not select anything then the entire current
folder will be copied). Type file name for new files at the bottom (you can use special tags to add
information about the file or replay, click Help button for a list of tags. It is recommended that
you use the <n> tag because it ensures that no files are overwritten). Then click the Batch Copy button.

 To enter replay information mode either select a replay file in the tree view or double click a replay
in folder view mode. If you do not see your replay in the tree view and it was recently added, try
clicking the Refresh button to the bottom of the list. You can also type in the path to the replay
and click Open (or use Browse button).
 The replay information mode has several tabs.

- Game Info tab shows general information about the game and a list of players and some stats. Note
 that game score is computed as a sum of deaths of enemy heroes and will not be correct in case of
 suicides, hero denies and neutral kills.
  If you right-click a player in the list, a menu will show up, allowing you to view build/actions for
 given player, copy stats to clipboard or find games for a given player

- Game Chat tab shows the chat as it was seen by the saving player.

- Timeline tab shows the DotA map and draws hero icons on it in predicted position for that hero at a
 given time. Since the replay file contains very limited information this view is far from being
 accurate (it is based on right-clicks) but should give you the general idea of what was happening in
 the game. If you move the mouse pointer over a hero you will see player name, hero name, hero level,
 learned skills and items for a given time. The items are assembled using a relatively simple algorithm
 that may also be a little incorrect (and does not know about items transferred between players).
  If a player was inactive for some time it is considered dead and removed from the screen until the
 player moves again (the hero will be placed at the fountain area). The amount of time is changed by the
 Death treshold option in the Settings (30 seconds by default).
  Also the program draws sentry/observer wards on the map. The method used for detecting placed wards
 may be a little wrong and can display extra wards (for instance when you issue order to place a ward
 and then cancel it). Wards last 6 minutes by default (this value can be changed in the Settings and
 is the same for sentry and observer wards since there's no way to find out which ward was placed).

- Builds tab shows skill and item builds for a given player. Select the player from the dropdown menu.
 The skill build list will contain the skill order and a time at which each skill was learned. Note
 that in some cases a learned skill can be recorded in the replay twice (if latency is big enough).
 To fight that you can set the minimal time between learned skills in the settings menu (Repeated
 action delay). Default value is 1 second, increase it if you see something wrong. Also if a hero,
 for example, gets levels 10 and 11 in a short period of time (teamfight) and first learns ultimate
 level 2 and then another skill then the build order will first show the other skill and then the
 ultimate skill (you can see that they were learned in a different order looking at the time).
 This is not a bug, it is a feature.
  But if you see a certain skill completely missing even though the player learned it (the hero will
 also appear underleveled) then please report it because some skill IDs may be wrong in the program
 (and they can also be different in other versions of DotA).
  Item list shows all items bought by a given player (repeated action delay is used in the same way 
 it was used for skills).

- Actions tab shows action analysis for a given player. Select the player from the dropdown menu. The
 first list will show different types of actions and how often the given player used them.
  The second list shows unit groups (those that are assigned with Ctrl+digit) used by a given player.
  The third list shows APM for a given player at different periods of time. This can be useful for
 detecting when the player was AFK or especially active.

- Gold timeline tab plots build costs for all players. Ticks next to player names allow you to select
 which graphs you want to see.
- Experience timeline works the same way as gold timeline does but shows player level instead of gold

- Presentation tab allows you to format replay information for sharing it with other people. There are
 many options and you can use one of the presets (available from the list). You can also save your set
 of options by giving it a unique name and clicking the Save button.
  The program can either output plain text, BB code for forum or HTML code.
  In BB code and HTML modes you can enable small icons for heroes, skills and items by checking the
 corresponding box. In BB code mode these images should be located in the internet - URL can be
 specified in the settings. By default the images are taken from my page created for that, but if you
 do not want to rely on the stability of the that website/hosting (it's a free host) you can use your
 own hosting. To do that open the "resources" file with any Zip program and put all the files on your
 server (do not change filenames). Then change the Image URL option in the settings (make sure to put
 a slash at the end of the URL). To save a little bit of space you can remove the files that do not
 start with BTN or PASBTN.
  Then you can choose what general information about the game you want to include.
  Then you can enable player list, choose options and whether to group players by lane.
  You can also enable detailed reports for some players - that is, build and action information.
  Note: in BB code version winner is displayed in a [spoiler] tag (so it is visible only if you select
 it).

- Draft tab shows hero pool for -cd mode and captain bans/picks for -cd/-cm modes

- Action log shows detailed low level log of the game. Press "Load actions" to parse the map and re-parse
 the replay, it takes about 10 seconds for a large map. Note that the map must be in your WC3 folder at
 the correct location.
 If "Show rawcodes" box is not set, item/unit/ability/etc IDs will be replaced by icon+name wherever
 possible

- Replay workshop allows you to remove some chat messages and pings from the replay. To open the workshop,
 load a replay and click "Workshop" on Game Info tab. You can remove all messages or all observer messages,
 and you can choose specific messages to remove (you are only allowed to remove messages during first 15
 seconds of the game). You can also remove all or observer minimap pings. Click OK and choose the file to
 save the new replay to.

 To find games played by a given player either right-click the player in game info tab of any replay and
select Find games or type "Player:<name>" in path bar and click Open.
 You will see a list of games with statistics for a given player. To sort the list click on any column
header. To sort in another direction, click the header again.
 To make sure all replays are searched for a given player, press the "Cache all replays" button in
Settings menu once (new replays will be cached when they are opened).

 You can quickly build a list of players that joined the current game by pressing Print Screen after you
joined a game, then select Parse Screenshot item in the tree view. The list will contain players in the
game, number of games you played with them, their best/worst K-D and number of games they won. Also it
shows which players have played together to detect friend parties.
 The program extracts player names from the screenshot and works pretty well for 1280x1024 resoultion,
but usually detects wrong names with other resolutions. You can manually edit player names by selecting
a player, typing the correct name in the box and pressing Modify.
 To show the list of games played by a given player, double click a player in the list.

 You can also view replays for all or specific player for different heroes. Select Hero Chart item in
the tree view, type a player name (or leave it blank for any player), press Update, select a tavern,
hero and you will see a list of games. Double click a game to open it.

=============== Settings ==================================
Settings are opened by selecting the first item in the tree view.

- Warcraft folder: choose the Warcraft III installation path so that the program can find map files and
 MPQ archives.
- Replay folder: choose the path to the replay folder. If the folder contains too many files it not be
 fully displayed (to avoid hanging the program if a path like C: is entered).
- Maximum number of files: after the program finds this amount of files it will stop updating the tree
 view (see previous setting).

- View replays in windowed mode: when "View replay" button is clicked Warcraft III will launch in a
 windowed mode.

- Automatically view new replays: when the program detects that LastReplay.w3g file in the replay folder
 has been updated it will open it.
- Automatically copy new replays: when LastReplay.w3g is updated the program will create a copy of it
 (new file name is specified by the next option).
- Copy to file: specifies the new file name for automatically copier replays. Press Help for a list of
 available tags. It is recommended that you use the <n> tag because it ensures that no files are
 overwritten.

- Show details in folder view: in folder view additional information about replays will appear in columns
 to the right of file names. The following set of options determines which columns you want to appear.
- Save game cache (speeds up parsing file info): since parsing a replay takes some time, if you select
 columns like Game name or Game length file list may take a long time to appear. For this reason parsed
 replays are cached so that this info can be acquired faster next time. If you check this box cached
 information will be saved to a file so that it will be available next time you launch this program.
  Cached information is also used for searches.
  To cache all games click "Cache all replays" button.

- Minimize to system tray: check this box to hide the program window and display a small icon in the
 Notification area (lower right corner of the screen) when it is minimized. Useful when the program is
 running in background mode, saving replays.
- Enable URL in path bar (make sure you type http://): if the requested replay file name starts with
 http: then the program will attempt to look for in in the internet.
- Check for updates automatically (every day): check this box to allow the program to connect to
 internet once in a day and check for updates (when you run this program).
- Set this program as default for opening replays: check this box to use this program for opening
 replay files, uncheck it to use Warcraft III

- Your name(s) (if replay saver was not found): list the names you use when playing (separated by spaces).
 If replay parser could not be identified for some reason, this information will be used instead.

- Repeated action delay for skills (ms): specifies the mimimal amount of time that should pass between two
 learned skills - because the replay can sometimes contain several learn skill actions when a player clicks
 the button too quickly.
- Repeated action delay for items (ms): specifies the mimimal amount of time that should pass between two
 bought items - because the replay can sometimes contain several buy item actions when a player clicks
 the button too quickly.

- Draw wards: check this box to see wards in Timeline mode.
- Ward lifetime (seconds): set the amount of time a single ward lasts. Since the program cannot determine
 whether the ward is sentry or observer they have a common lifetime.
- Draw chat: check this box to see chat in Timeline mode.
- Chat fade time (seconds): set the amount of time a chat message lasts on a screen (it will dissappear
 faster if game speed is increased).
- Draw minimap pings: check this box to see minimap pings in Timeline mode.
- Death treshold (seconds): set the amount of time a player has to be inactive to be considered dead
 (the hero icon is hidden until the player moves again and then the hero is spawned at the tavern area).
 Increase this option if heroes sometimes dissapear and come out from the tavern area when they shouldn't.

- Show skill levels in build view: check this box to append skill levels to skill names in build list.
- Color skills in build view: check this box to use colors for skills: green, blue, yellow, red and white
 for first, second, third, ultimate skill and attribute bonuses.
- Show assembled items in itembuild: check this box to view completed items in itembuild list (colored
 green), removed items will be colored gray.
- Synchronize selection in build view: check this box to select last bought item when you select a skill
 select last learned skill when you select an item in build view.

- Image URL: set the path to the folder containing images for Presentation function. This path should
 point to internet server for BB code mode. By default it points to my other project, but I cannot
 guarantee that it will stay there so if you use the Presentation function a lot it is recommended
 that you set up your own path (see Presentation tab section for more information).

- Smoother gold timeline: check this box to remove sharp jumps in gold timeline (which appear when player
 buys several items at the same time).

- Log actions: check this box to create a log.txt file containing most player's actions with ItemIDs,
 coordinates, ObjectIDs.
- Ignore basic actions: check this box to avoid including basic actions like Rightclick, move/attac/stop,
 Pre subselection in log files.

- Cache all replays: goes through every replay in the Replays folder and retrieves some information from
 them for searches and viewing details in folders. Clicking this button is only required for finding games
 for a player.
  Note: retrieved information is only saved to a file if "Save game cache" option is selected.

d07.RiV@gmail.com
